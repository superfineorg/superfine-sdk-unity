using UnityEditor;

namespace Superfine.Unity
{
    [CustomEditor(typeof(SuperfineSDKAppsFlyerAdRevenueSettings), true)]
    public class SuperfineSDKAppsFlyerAdRevenueSettingsEditor : SuperfineSDKBaseSettingsEditor
    {
    }
}
