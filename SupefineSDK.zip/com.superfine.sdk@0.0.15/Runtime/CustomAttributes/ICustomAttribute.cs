﻿namespace Superfine.Unity
{
    public interface ICustomAttribute
    {
    }
}
