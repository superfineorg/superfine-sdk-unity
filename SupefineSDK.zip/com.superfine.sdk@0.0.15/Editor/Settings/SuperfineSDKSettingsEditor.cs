﻿using UnityEditor;

namespace Superfine.Unity
{
    [CustomEditor(typeof(SuperfineSDKSettings), true)]
    public class SuperfineSDKSettingsEditor : SuperfineSDKBaseSettingsEditor
    {
    }
}
