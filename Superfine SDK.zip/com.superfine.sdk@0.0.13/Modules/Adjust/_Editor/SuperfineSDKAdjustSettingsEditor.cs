using UnityEditor;

namespace Superfine.Unity
{
    [CustomEditor(typeof(SuperfineSDKAdjustSettings), true)]
    public class SuperfineSDKAdjustSettingsEditor : SuperfineSDKBaseSettingsEditor
    {
    }
}
