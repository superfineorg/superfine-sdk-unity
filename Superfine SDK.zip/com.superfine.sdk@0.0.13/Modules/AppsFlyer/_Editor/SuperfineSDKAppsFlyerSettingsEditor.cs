using UnityEditor;

namespace Superfine.Unity
{
    [CustomEditor(typeof(SuperfineSDKAppsFlyerSettings), true)]
    public class SuperfineSDKAppsFlyerSettingsEditor : SuperfineSDKBaseSettingsEditor
    {
    }
}
