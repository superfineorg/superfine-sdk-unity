using UnityEditor;

namespace Superfine.Unity
{
    [CustomEditor(typeof(SuperfineSDKTenjinSettings), true)]
    public class SuperfineSDKTenjinSettingsEditor : SuperfineSDKBaseSettingsEditor
    {
    }
}
