using UnityEditor;

namespace Superfine.Unity
{
    [CustomEditor(typeof(SuperfineSDKSingularSettings), true)]
    public class SuperfineSDKSingularSettingsEditor : SuperfineSDKBaseSettingsEditor
    {
    }
}
