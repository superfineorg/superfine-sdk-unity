﻿using UnityEngine;

namespace Superfine.Unity
{
    public class DrawerAttribute : PropertyAttribute
    {
    }
}
