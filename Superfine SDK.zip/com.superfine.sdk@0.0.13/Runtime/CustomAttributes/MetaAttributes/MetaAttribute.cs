﻿using System;

namespace Superfine.Unity
{
    public class MetaAttribute : Attribute, ICustomAttribute
    {
    }
}
