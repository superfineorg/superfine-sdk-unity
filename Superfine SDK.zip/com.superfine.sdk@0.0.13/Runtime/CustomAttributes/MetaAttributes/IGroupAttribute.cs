﻿using UnityEngine;

namespace Superfine.Unity
{
    public interface IGroupAttribute
    {
    }
}
