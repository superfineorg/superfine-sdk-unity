﻿namespace Superfine.Unity
{
    public enum EConditionOperator
    {
        And,
        Or
    }
}
