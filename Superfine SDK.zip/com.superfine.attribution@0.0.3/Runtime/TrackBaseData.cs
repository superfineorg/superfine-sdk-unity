using System;

namespace Superfine.Tracking.Unity
{
    [Serializable]
    public class TrackBaseData
    {
    }
}